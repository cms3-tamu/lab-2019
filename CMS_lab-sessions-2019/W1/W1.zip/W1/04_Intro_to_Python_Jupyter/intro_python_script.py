def is_negative(input):
    if input < 0:
        return True
    else:
        return False

# Strings can have single or double quotes
name = 'Enze Chen'
age = 23
result = is_negative(input=age)
print(result)
