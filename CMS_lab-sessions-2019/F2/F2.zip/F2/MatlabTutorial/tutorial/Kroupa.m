function F = Kroupa(b1,b2,t1,t2,mu,nu)

R = cross(t1,t2);

F1 = 0.5*dot(b1,t1)*dot(b2,t2) - dot(cross(b1,b2),cross(t1,t2));
F2 = dot(cross(b1,t1) ,R/norm(R)) * dot(cross(b2,t2),R/norm(R));

F = (F1 + F2/(1-nu)) * dot(R,R);

end




function F12 = InteractionForce(b1,b2,t1,t2,R12,mu,nu)
    
    normy =norm(cross(t1,t2));
    
   if (normy < 1e-6)
        %dislocation are parallel. Use (5-17) formula.
        Fac = 1./(2*pi);
        F12 = Fac*(dot(b1,t1) * dot(b2,t1) + dot(cross(b1,t1),cross(b2,t1))/(1-nu) );
   else
       %dislocation are not parallel. Use (5-35) formula.
        R12u = R12/norm(R12);
        Fac = mu/(norm(R12)*normy);   
        F12 = Fac*( 0.5* dot(b1,t1) * dot(b2,t2) - dot(cross(b1,b2),cross(t1,t2)) + ...
                   dot(cross(b1,t1),R12u) * dot(cross(b2,t2),R12u)/(1-nu));
   end
end
