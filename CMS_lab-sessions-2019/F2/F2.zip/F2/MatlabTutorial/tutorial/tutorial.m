% Tutorial : Junction creation
% Author : Sylvie Aubry
%
% Question: When do two parallel dislocations create a junction?
% Answer: it depends on the angle the dislocation make

% Goal of the tutorial
% Show how the angle between two dislocations influences junction
% formation.


close all;
clear all;
clc;

global Bscrew Bedge Bclimb Bline

totalsteps=100;

appliedstress = zeros(3,3);

mobility='mobfcc0';

b1 = [  0   1   1  ]/2;
b2 = [  1  -1   0  ]/2;

n1 = [-1 1 -1]/sqrt(3);  
n2 = [ 1 1  1]/sqrt(3);  

t1 = 1/sqrt(6) * [2 1 -1];
t2 = 1/sqrt(6) * [1 1 -2];

L = 2000;

R = cross(t1,t2);
R = R/norm(R);

d = 10;
R = d*R;

rn = [ -t1*L + R 7
        t1*0 + R 0
        t1*L + R 7
       -t2*L - R 7
        t2*0 - R 0
        t2*L - R 7 ];
    
links = [ 1 2   b1 n1
          2 3   b1 n1
          4 5   b2 n2
          5 6   b2 n2 ];

maxconnections=8;
lmax = 1000;
lmin = 200;
a=10;
MU = 1.3e11;
NU = 0.309; 
Ec = MU/(4*pi)*log(a/0.1);

areamin=lmin*lmin*sin(60/180*pi)*0.5; % minimum discretization area
areamax=20*areamin; % maximum discretization area
dt0=1e-5;           %maximum time step
plotfreq=1;       %plot nodes every how many steps
plim=2000;          %plot x,y,z limit (nodes outside not plotted)

viewangle=[60 30];
printfreq=1;      %print out information every how many steps
printnode=3;

integrator='int_trapezoid';

rann = 10;       %annihilation distance (capture radius)
%rntol=1e-1;       %tolerance for integrating equation of motion
rntol = 2*rann;      % on Tom's suggestion
rmax=30;

doremesh    =1;
docollision =1;
doseparation=1;


Bscrew=1e0;
Bedge=1e0;
Bclimb=1e2;
Bline=1.0e-4*min(Bscrew,Bedge);



dd3d

