function [vn,fn] = moblinear(fseg,rn,links,connectivity,nodelist,conlist)
% Relaxation : v = f/L.

% length of the nodelist for which the velocity will be calculated
L1=size(nodelist,1);
% if no nodelist is given then the nodelist becomes the whole node population
% this portion of the code sets up that nodelist along with the connlist
% that contains all of the nodal connections
if L1==0
    L1=size(rn,1);
    nodelist=linspace(1,L1,L1)';
    [L2,L3]=size(connectivity);
    conlist=zeros(L2,(L3-1)/2+1);
    conlist(:,1)=connectivity(:,1);
    for i=1:L2
        connumb=conlist(i,1);
        conlist(i,2:connumb+1)=linspace(1,connumb,connumb);
    end
end
% now cycle through all of the nodes for which the velocity must be calculated

for n=1:L1
    n0=nodelist(n);                 %n0 is the nodeid of the nth node in nodelist
    numNbrs=conlist(n,1);           %numNbrs is the number of connections for node n0 in conlist
    fn(n,:)=zeros(1,3);             % initialize the total force and the total drag matrix
    Lsum = 0.0;

    % Sum forces over the arms of the node
    for i=1:numNbrs
        ii=conlist(n,i+1);                                       % connectionid for this connection
        linkid=connectivity(n0,2*ii);
        posinlink=connectivity(n0,2*ii+1);
        n1=links(linkid,3-posinlink);
        rt=rn(n1,1:3)-rn(n0,1:3);                                % calculate the length of the link and its tangent line direction
        L=norm(rt);
        if L>0.0
            fsegn0=fseg(linkid,3*(posinlink-1)+[1:3]);
            fn(n,:)=fn(n,:)+fsegn0; % nodeid for the node that n0 is connected to
            Lsum = Lsum + L;
        end
    end
    
    vn(n,:)=fn(n,:); 



   if numNbrs==2
       ii=conlist(n,2);                                                                      
       n1=links(connectivity(n0,2*ii),3-connectivity(n0,2*ii+1));
       ii=conlist(n,3);                                                                      
       n2=links(connectivity(n0,2*ii),3-connectivity(n0,2*ii+1));
       rt=rn(n1,1:3)-rn(n2,1:3);
       L=norm(rt);
       linedir=rt./L;
       vn(n,:)=((eye(3)-linedir'*linedir)*vn(n,:)')';
   end

end

end