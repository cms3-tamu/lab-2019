### Non-linear simulation using UMAT
### FFTMAD version 05/2019
### variational approach, finite strain, crystal plasticity
### Uniaxial tension on a single crystal


from SOLVERS.solverclass import simulation
from MAT_MODELS.materials import material
from POST.toParaview import toParaview
import numpy as np
import matplotlib.pyplot as plt

folder='results/'
   
#define simulation
my_simulation=simulation('single_crystal','non-linear','variational-nw-cg-finite')
my_simulation.set_options(nlgeom='yes')

#define options
my_simulation.set_tolerances(toler_nw=1e-6,toler_lin=1e-8)

#Model geometry
# Homogeneous model, one single crystal
my_simulation.ndim=3
my_simulation.n=[3,3,3]
my_simulation.L=[1,1,1]
my_simulation.prop=np.ones([3,3,3],dtype=int)
my_simulation.L=[1.,1.,1.]

# Material models and Properties
my_materials=[]
ffm = open(folder+'pmat.txt', 'w')
orientation=[1.,0,0,0,1,0] # UMAT properties: Orientation 100, 010
my_materials.append(material('in718','umat',folder='umat_cp_phen_iso'))
my_materials[-1].set_properties(props=np.append(orientation[0:6],0.),sdv_num=46)
ffm.write('%f %f %f %f %f %f %f\n' % \
          (orientation[0],orientation[1],orientation[2],orientation[3],orientation[4],orientation[5],0.))
ffm.close()
 

#Define loads
my_simulation.set_load_step(F_ave_goal=[[1.05,0,0],[0,1.0,0],[0,0,1.0]],\
                       stress_ave_goal=[[0,0,0],[0,0,0],[0,0,0]],\
                       timer=[0.1,1.,0.001,0.1],
                       info=[9,10,11,12,13,14,15,16,17,18,19,20,21],frec=1,incfix=0,control=[[0,1,1],[1,1,1],[1,1,1]])

# Solving sequence
my_simulation.generate_green(filterfreq='no')
my_simulation.set_FP(my_materials)
my_simulation.solve(output=folder+'single_')

##post
toParaview(my_simulation)

## Saving data to disk
f=open(folder+'single'+'.txt','w')
for ii in range(len(my_simulation.F_ave_inc[:,0,0])):
    f.write('%f %f \n' % (my_simulation.F_ave_inc[ii,0,0],my_simulation.PK1stress_ave_inc[ii,0,0]))
f.close()
    
fig, ax = plt.subplots()
ax.plot(my_simulation.F_ave_inc[:,0,0],my_simulation.PK1stress_ave_inc[:,0,0],label=' stres 00')
ax.plot(my_simulation.F_ave_inc[:,0,0],my_simulation.PK1stress_ave_inc[:,1,1],label=' stres 11')
ax.legend(loc='upper left')