# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 23:55:17 2019

@author: marsh
"""

def model_builder(X_train,X_test,y_train,y_test,kernel,local_gp,n_clusters,normalize_cluster,plot_inputs,
                  pc_scores,plot_parity):
    
    import numpy as np
    import matplotlib.pyplot as plt
    from sklearn.gaussian_process import GaussianProcessRegressor
    
    if local_gp==1:
        from sklearn.cluster import KMeans
        X_train_local={}
        X_test_local={}
        y_train_local={}
        y_test_local={}
        preds={}
        err={}
        
        if normalize_cluster==1:
            X_total=np.append(X_train,X_test,axis=0)
            max_X=X_total.max(axis=0)
            min_X=X_total.min(axis=0)
            X_train=(X_train-min_X)/(max_X-min_X)
            X_test=(X_test-min_X)/(max_X-min_X)
        
        cluster_obj=KMeans(n_clusters=n_clusters).fit(X_train)
        clusters_train=cluster_obj.predict(X_train)
        clusters_test=cluster_obj.predict(X_test)
        
        if normalize_cluster==1:
            X_train=X_train*(max_X-min_X)+min_X
            X_test=X_test*(max_X-min_X)+min_X
            
        for i in range(n_clusters):
            X_train_local[i]=X_train[np.where(clusters_train==i)[0]]
            X_test_local[i]=X_test[np.where(clusters_test==i)[0]]
            test=np.where(clusters_train==i)[0]
            y_train_local[i]=y_train[np.where(clusters_train==i)[0]]
            y_test_local[i]=y_test[np.where(clusters_test==i)[0]]
        
        if plot_inputs==1:
            
            plt.figure()
            
            for i in range(n_clusters):
                plt.plot(X_train_local[i][:,pc_scores[0]-1],X_train_local[i][:,pc_scores[1]-1],'.')
                plt.xlabel('PC{}'.format(pc_scores[0]))
                plt.ylabel('PC{}'.format(pc_scores[1]))
                plt.title('Training inputs in PC space')
                
            plt.figure()
            
            for i in range(n_clusters):
                plt.plot(X_test_local[i][:,pc_scores[0]-1],X_test_local[i][:,pc_scores[1]-1],'.')
                plt.xlabel('PC{}'.format(pc_scores[0]))
                plt.ylabel('PC{}'.format(pc_scores[1]))
                plt.title('Testing inputs in PC space')
                
        for i in range(n_clusters):
            gp=GaussianProcessRegressor(kernel=kernel)
            gp=gp.fit(X_train_local[i],y_train_local[i])
            preds[i]=gp.predict(X_test_local[i])
            preds[i][np.where(preds[i]<0)]=0
            preds[i][np.where(preds[i]>1)]=1
            preds[i][np.where(X_test_local[i][:,10]==1)[0]]=1
            err[i]=abs(y_test_local[i]-preds[i])
            
            if i==0:
                error_total=err[i]
                y_test_total=y_test_local[i]
                preds_total=preds[i]
            else:
                error_total=np.append(error_total,err[i])
                y_test_total=np.append(y_test_total,y_test_local[i])
                preds_total=np.append(preds_total,preds[i])
                
        pmae=np.round(100*np.sum(error_total)/np.sum(y_test_total),3)
        
        if plot_parity==1:
            plt.figure()
            plt.plot(y_test_total,y_test_total,'k')
            plt.plot(y_test_total,preds_total,'b.')
            plt.xlabel('Simulation result')
            plt.ylabel('GPR prediction')
            plt.title('$\chi_2$')
    
    else:
        
        if plot_inputs==1:
            plt.figure()
        
            plt.plot(X_train[:,pc_scores[0]-1],X_train[:,pc_scores[1]-1],'.')
            plt.xlabel('PC{}'.format(pc_scores[0]))
            plt.ylabel('PC{}'.format(pc_scores[1]))
            plt.title('Training inputs in PC space')
            
            plt.figure()
        
            plt.plot(X_test[:,pc_scores[0]-1],X_test[:,pc_scores[1]-1],'.')
            plt.xlabel('PC{}'.format(pc_scores[0]))
            plt.ylabel('PC{}'.format(pc_scores[1]))
            plt.title('Testing inputs in PC space')
        
        gp1=GaussianProcessRegressor(kernel=kernel)
        gp1=gp1.fit(X_train,y_train)
        pred=gp1.predict(X_test)
        
        pred[np.where(pred<0)]=0
        pred[np.where(pred>1)]=1
        pred[np.where(X_test[:,10]==1)[0]]=1
        
        pmae=np.round(100*np.sum(abs(y_test-pred))/np.sum(y_test),2)
    
        if plot_parity==1:
            plt.figure()
            plt.plot(y_test,y_test,'k')
            plt.plot(y_test,pred,'b.')
            plt.xlabel('Simulation result')
            plt.ylabel('GPR prediction')
            plt.title('$\chi_2$')
    
    print('My percent mean absolute error is {}%'.format(pmae))