# -*- coding: utf-8 -*-
"""
Created on Tue Jul 23 22:19:36 2019

@author: marsh
"""

def voronoi_2d(n_regions,dim,volfrac_target):

    import numpy as np
    import random
    
    volfrac_orig=volfrac_target
    
    coords=np.zeros((n_regions,2))
    
    for i in range(n_regions):
        coords[i]=[dim*random.random(),dim*random.random()]
    
    pointrange=np.arange(dim)
    grid_points=np.array(np.meshgrid(pointrange,pointrange)).T.reshape(-1,2)
    
    dists_phases=np.zeros(grid_points.shape[0])    
    
    dists=np.zeros((grid_points.shape[0],n_regions))
    dists_low={}
    dists_low2=np.zeros(grid_points.shape[0])
    
    for i in range(grid_points.shape[0]):
        for j in range(n_regions):
            dists[i,j]=((grid_points[i,0]-coords[j,0])**2+(grid_points[i,1]-coords[j,1])**2)**0.5 #Euclidean distance
        dists_low[i]=np.where(dists[i,:]==min(dists[i,:]))[0][0]
        dists_low2[i]=dists_low[i]
    
    region_list={}
    region_count=np.zeros(n_regions)
    
    for i in range(n_regions):
        region_list[i]=np.where(dists_low2==i)[0]
        region_count[i]=len(region_list[i])
    
    region_sum=np.sum(region_count)
    region_norm=np.zeros(n_regions)
    region_norm=region_count/region_sum
    sum_tot=0
    ind_list=np.arange(0,n_regions)
    region_norm2=np.append(region_norm.reshape(-1,1),ind_list.reshape(-1,1),axis=1)
    array_length=n_regions-1
    
    i=0
    
    target_index={}
    del_inds={}
    
    if volfrac_target>0.5:
        volfrac_target=1-volfrac_target
    
    while i<=n_regions:
        target_index[i]=random.randint(0,array_length-1)
        array_length-=1
        if sum_tot+region_norm2[target_index[i],0]<volfrac_target:
            sum_tot+=region_norm2[target_index[i],0]
            del_inds[i]=int(region_norm2[target_index[i],1])
            region_norm2=np.delete(region_norm2,target_index[i],axis=0)
            i+=1
        else:
            diffs_array=np.append(np.zeros(array_length+2).reshape(-1,1),
                                  region_norm2[:,1].reshape(-1,1),axis=1)
            for j in range(diffs_array.shape[0]):
                diffs_array[j,0]=abs(volfrac_target-(sum_tot+region_norm[int(diffs_array[j,1])]))
            if abs(volfrac_target-sum_tot)<=abs(volfrac_target-(sum_tot+min(diffs_array[:,0]))):
                break
            else:
                ind_last=int(diffs_array[np.where(diffs_array[:,0]==min(diffs_array[:,0]))[0][0],1])
                sum_tot+=region_norm[ind_last]
                del_inds[i]=ind_last
                break
    
    if volfrac_target<=0.5:        
        region_phases=np.ones(n_regions)
    
        for i in range(len(del_inds)):
            region_phases[del_inds[i]]=0
        
    else:
        region_phases=np.zeros(n_regions)
        
        for i in range(len(del_inds)):
            region_phases[del_inds[i]]=1
            
    dists_phases=np.zeros(grid_points.shape[0]) 
    
    for i in range(grid_points.shape[0]):
        dists_phases[i]=region_phases[dists_low[i]]
        
    if volfrac_orig<0.5:
        inds_zeros=np.where(dists_phases==0)[0]
        inds_ones=np.where(dists_phases==1)[0]
    else:
        inds_zeros=np.where(dists_phases==1)[0]
        inds_ones=np.where(dists_phases==0)[0]
    
    volfrac=np.array([len(inds_zeros)/len(dists_phases),len(inds_ones)/len(dists_phases)])
    
    X=np.zeros((dim,dim))
    X[grid_points[inds_ones][:,0],grid_points[inds_ones][:,1]]=1
    X=X.reshape(1,dim,dim)
    
    return X

def random_2d(dim,volfrac_target):
    import numpy as np
    inds=np.arange(dim**2)
    n_zeros=int(volfrac_target*dim**2)
    zero_inds=np.random.choice(inds,n_zeros,replace=False)
    mic_array=np.ones(dim**2)
    mic_array[zero_inds]=0
    mic_array=mic_array.reshape(1,dim,dim)
    
    return mic_array