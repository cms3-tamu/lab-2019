#! /usr/bin/python

import  os
import  string
import  sys

def error() :
   print "syntax: file col sign lim"
   sys.exit(0)

def main1() :

    pb = sys.argv[1];
    os.system("Zrun -pp %s" % (pb))
    fin  = open("%s.post" % (pb),'r')
    lines = fin.readlines()

    if len(lines)<10 : sys.exit(0)

    broken = float(lines[-1].split()[1])
    if broken > 0.5 :
       sys.exit(1)
    else :
       sys.exit(0)

def main2() :

    pb = sys.argv[1];
    os.system("Zrun -pp %s" % (pb))
    fin  = open("%s.post" % (pb),'r')
    lines = fin.readlines()

    if len(lines)<3 : sys.exit(0)

    time = float(lines[-1].split()[0])
    if time > 50. :
       sys.exit(1)
    else :
       sys.exit(0)

def main3() :
   pb=sys.argv[1]+".test"
   lines =  open(pb,'r').readlines()

   Fmax=0.

   for line in lines :
      items=line.split()
      if len(items)<= 2 :   continue
      try :
          F=float(items[3])
      except :
          continue
      if F>Fmax :
         Fmax=F
      elif F<0.25*Fmax :
         sys.exit(1)
   sys.exit(0)

def main() :
    main3()


main()
